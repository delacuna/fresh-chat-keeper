(function() {
  "use strict";
  chrome.runtime.onInstalled.addListener((_details) => {
  });
})();
